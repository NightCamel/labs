#include <stdio.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/sem.h>
#include <semaphore.h>
#define MAX_COUNT 100
sem_t thread_sem[MAX_COUNT + 1], main_sem;

typedef struct{
    char *string;
    bool killed;
    int thread_current;
}pthrData;

int kbhit()
{
    fd_set rfds;
    struct timeval tv;

    FD_ZERO(&rfds);
    FD_SET(0,&rfds);
    tv.tv_sec=0;
    tv.tv_usec=100;
 
    return select(1,&rfds,NULL,NULL,&tv);
}

void *thread_function(void* threadData)
{
    pthrData *data = (pthrData*) threadData;
    while(1){
        sem_wait(&thread_sem[data->thread_current]);
        if(data->killed == false){
            pthread_exit(0);
        }
        for(int i = 0; data->string[i] != '\0'; i++){
            printf("%c", data->string[i]);
        }
        printf("%d", data->thread_current);
        sem_post(&main_sem);
    }
}

int main(void) {
    initscr();
    clear();
    noecho();
    refresh();
    char* strings = "\r\nThread nubmer ";
    char c = 0;
    pthread_t threads[MAX_COUNT + 1];
    pthrData threadData[MAX_COUNT + 1];
    int sizeOfThreads = 0, res;
    res = sem_init(&main_sem, 0, 1);
    if (res != 0) {
        perror("Semaphore initialization failed");
        exit(EXIT_FAILURE);
    }
    while(c!='q'){
        refresh();
        fflush(stdin);
        if(!kbhit()){
            //sleep(1);
            for(int i = 1; i <= sizeOfThreads; i++){
                if(kbhit()){
                    break;
                }
                sem_wait(&main_sem);
                sem_post(&thread_sem[i]);	
                usleep(300000);
            }
        }
        else {
            fflush(stdin);
            switch(c=getchar()){
                case '+': {
                    if(sizeOfThreads < MAX_COUNT){
                        sizeOfThreads++;
                    }
                    else{
                        printf("\r\nTo much threads!\n");
                        break;
                    }
                    if(sizeOfThreads<0) sizeOfThreads = 0;
                    threadData[sizeOfThreads].killed = true;
                    threadData[sizeOfThreads].thread_current = sizeOfThreads;
                    threadData[sizeOfThreads].string = strings;
                    res = sem_init(&thread_sem[sizeOfThreads], 0 , 0);
                    if((res = pthread_create(
                                            &threads[sizeOfThreads],//id нового потока
                                            NULL,//поток создан с стандартными атрибутами
                                            thread_function,//указатель на потоковую функцию
                                            &threadData[sizeOfThreads]//значение аргумента потока
                                            )) < 0)//если поток создан успешно- функция возвращает 0
                    perror("pthread_create");                
                }
                break;
                case '-': {
                    if(sizeOfThreads == 0)
                        printf("\r\nThere are no threads!\r\n");
                    else {
                        threadData[sizeOfThreads].killed = false;
                        sem_post(&thread_sem[sizeOfThreads]);
                        sem_destroy(&thread_sem[sizeOfThreads]);
                        sizeOfThreads--;
                        refresh();
                    }
                }
                break;
            }
        }
        refresh();
    }
    if(threads[sizeOfThreads] > 0){
        for(; sizeOfThreads > 0; sizeOfThreads--){
            threadData[sizeOfThreads].killed = false;
            sem_post(&thread_sem[sizeOfThreads]);
            sem_destroy(&thread_sem[sizeOfThreads]);
        }
        refresh();
    }
    sem_destroy(&main_sem);
    rewind(stdin);
    clear();
    refresh();
    endwin();
    return 0;
}
